package com.myorg.leaveapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.myorg.leaveapp.bean.Leaves;

public class LeavesDAO {
	public boolean insert(Leaves leaves) throws SQLException, ClassNotFoundException
	{
		ConnectionFactory factory=new ConnectionFactory();
		factory.connect();
		Connection con = factory.getConnection();
		String quary = "insert into leaves(uid,ltype,applied_date,from_date,to_date,status,description,reason)values (?,?,?,?,?,?,?,?)";
		PreparedStatement st = con.prepareStatement(quary);
		
		
		st.setInt(1, leaves.getUid());
		st.setString(2, leaves.getLtype());
		st.setString(3, leaves.getApplied_date());
		st.setString(4, leaves.getFrom_date());
		st.setString(5, leaves.getTo_date());
		st.setString(6, leaves.getStatus());
		st.setString(7, leaves.getDescription());
		st.setString(8, leaves.getReason());
		
		st.executeUpdate();
		
		
		System.out.println("Data Inserted !!!");
		factory.closeConnection();
		return false;
		
	}
	public ArrayList<Leaves> selectAll() throws ClassNotFoundException, SQLException
	{
		ConnectionFactory factory=new ConnectionFactory();
		factory.connect();
		Connection con = factory.getConnection();
		
		String quary = "select * from leaves where status='applied'";
		PreparedStatement ps = con.prepareStatement(quary);
		ArrayList<Leaves> al= new ArrayList<Leaves>();
		
		ResultSet rs = ps.executeQuery();
		
		while(rs.next())
		{ 
		 
		 Leaves leaves= new Leaves();
		 
		 leaves.setLid(rs.getInt("lid"));
		 leaves.setUid(rs.getInt("uid"));
		 leaves.setLtype(rs.getString("ltype"));
		 leaves.setApplied_date(rs.getString("applied_date"));
		 leaves.setFrom_date(rs.getString("from_date"));
		 leaves.setTo_date(rs.getString("to_date"));
		 leaves.setStatus(rs.getString("status"));
		 leaves.setDescription(rs.getString("description"));
		 leaves.setReason(rs.getString("reason"));
		 al.add(leaves);
		 
		}
		factory.closeConnection();
		return al;
	}
	
	public void updateAllStatus(HashMap<String, String> actionmap) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory factory=new ConnectionFactory();
		factory.connect();
		Connection con = factory.getConnection();
		
		for(Map.Entry<String, String> entery:actionmap.entrySet())
		{
			int key =Integer.parseInt(entery.getKey());
			String value =entery.getValue();
			
			String quary="update leaves set status=? where lid=?";
			PreparedStatement ps = con.prepareStatement(quary);
			try
			{
			ps=con.prepareStatement(quary);
			ps.setString(1, value);
			ps.setInt(2, key);
			ps.executeUpdate();
			}
			catch (SQLException e) {
				System.out.println("=====Exception=======");
				e.printStackTrace();
			}
			ps.close();
			
			factory.closeConnection();
			
		}
		
	}
	
	

}
