package com.myorg.leaveapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;

import com.myorg.leaveapp.bean.User;

public class UserDAO {
	
	public boolean insert(User user) throws SQLException,ClassNotFoundException
	{
		ConnectionFactory factory=new ConnectionFactory();
		factory.connect();
		Connection con = factory.getConnection();
		String quary = "insert into user(username,passward,role,status) values (?,?,?,?)";
		PreparedStatement st = con.prepareStatement(quary);
		st.setString(1, user.getUsername());
		st.setString(2, user.getPassward());
		st.setString(3, user.getRole());
		st.setString(4, user.getStatus());
		st.executeUpdate();
		System.out.println("Data Inserted !!!");
		factory.closeConnection();
		return false;
		
	}
	
	public User chakeValidUser(String username,String passward) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory factory=new ConnectionFactory();
		factory.connect();
		Connection con = factory.getConnection();
		ResultSet rs=null;
		User user=null;
		
		String quary = "select * from user where username=? and passward=?";
		
		PreparedStatement st = con.prepareStatement(quary);
		st.setString(1, username);
		st.setString(2, passward);
		
		 rs =st.executeQuery();
		
		
		if(rs!=null)
		{
		 try {
			rs.next();
	        int uid =rs.getInt("uid");
			String username1=rs.getString("username");
			String passward1=rs.getString("passward");
			String role=rs.getString("role");
			String status=rs.getString("status");
			
			user = new User();
			user.setUid(uid);
			user.setUsername(username1);
			user.setPassward(passward1);
			user.setRole(role);
			user.setStatus(status);
			if(user.getUsername().equals(username1) && user.getPassward().equals(passward1) && user.getStatus().equals(status))
			{
				con.close();
				return user;
			}
		}catch (SQLException e) {
			System.out.println("Invalid User");
		}
		 
		}
		return user;		
	}

}
