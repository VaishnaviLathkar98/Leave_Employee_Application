package com.myorg.leaveapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	
	public static final String url="jdbc:mysql://localhost:3306/useme";
	public static final String username="root";
	public static final String passward="root";
	
	Connection con;
	public ConnectionFactory()
	{
		con=null;
	}
	public boolean connect() throws SQLException,ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(url,username,passward);
		if(con!=null)return true;
		return false;
		
	}
	public Connection getConnection()
	{
		return con;
		
	}
	
	public void closeConnection() throws SQLException
	{
		con.close();
	}
	

}
