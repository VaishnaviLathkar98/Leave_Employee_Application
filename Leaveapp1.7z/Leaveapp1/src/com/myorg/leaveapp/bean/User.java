package com.myorg.leaveapp.bean;

public class User {
	private int uid;
	private String username;
	private String passward;
	private String role;
	private String status;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(int uid, String username, String passward, String role, String status) {
		super();
		this.uid = uid;
		this.username = username;
		this.passward = passward;
		this.role = role;
		this.status = status;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassward() {
		return passward;
	}
	public void setPassward(String passward) {
		this.passward = passward;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", username=" + username + ", passward=" + passward + ", role=" + role + ", status="
				+ status + "]";
	}
	

}
