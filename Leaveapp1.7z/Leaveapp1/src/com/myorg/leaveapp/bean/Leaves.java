package com.myorg.leaveapp.bean;

public class Leaves {
	private int lid;
	private int uid;
	private String ltype;
	private String applied_date;
	private String from_date;
	private String to_date;
	private String status;
	private String description;
	private String reason;
	
	public Leaves() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Leaves(int lid, int uid, String ltype, String applied_date, String from_date, String to_date, String status,
			String description, String reason) {
		super();
		this.lid = lid;
		this.uid = uid;
		this.ltype = ltype;
		this.applied_date = applied_date;
		this.from_date = from_date;
		this.to_date = to_date;
		this.status = status;
		this.description = description;
		this.reason = reason;
	}

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getLtype() {
		return ltype;
	}

	public void setLtype(String ltype) {
		this.ltype = ltype;
	}

	public String getApplied_date() {
		return applied_date;
	}

	public void setApplied_date(String applied_date) {
		this.applied_date = applied_date;
	}

	public String getFrom_date() {
		return from_date;
	}

	public void setFrom_date(String from_date) {
		this.from_date = from_date;
	}

	public String getTo_date() {
		return to_date;
	}

	public void setTo_date(String to_date) {
		this.to_date = to_date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "Leaves [lid=" + lid + ", uid=" + uid + ", ltype=" + ltype + ", applied_date=" + applied_date
				+ ", from_date=" + from_date + ", to_date=" + to_date + ", status=" + status + ", description="
				+ description + ", reason=" + reason + "]";
	}

	
}
