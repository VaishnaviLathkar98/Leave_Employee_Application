package com.myorg.leaveapp.controler;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myorg.leaveapp.bean.Leaves;
import com.myorg.leaveapp.dao.LeavesDAO;

public class ProcessLeavesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public ProcessLeavesController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LeavesDAO leavesDAO = new LeavesDAO();
		
		try {
			ArrayList<Leaves> al=(ArrayList<Leaves>)leavesDAO.selectAll();
			
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			
			out.write("<form action=ProcessLeavesStatusUpdateController>"); 
			out.write("<table name=\"list\" border=\"1\" align=\"center\"");
			out.write("<tr>");
			out.write("<td align=\"center\">Leaves type</tr>");
			out.write("<td align=\"center\">Applied date</td>");
			out.write("<td align=\"center\">From_date</td>");
			out.write("<td align=\"center\">To_date</td>");
			out.write("<td align=\"center\">status</td>");
			out.write("<td align=\"center\">Reason</td>");
			out.write("<td align=\"center\">Action</td>");
			out.write("</tr>");
			
			for(Leaves leaves:al)
			{
				out.write("<tr>");
				out.write("<td align=\"left\">" +leaves.getLtype());
				out.write("<td align=\"center\">"+leaves.getApplied_date());
				out.write("<td align=\"center\">"+leaves.getFrom_date());
				out.write("<td align=\"center\">"+leaves.getTo_date());
				out.write("<td align=\"center\">"+leaves.getStatus());
				out.write("<td align=\"center\">"+leaves.getReason());
				
				out.write("<td align=\"left\">");
				int leavesid=leaves.getLid();
				out.print("<select name=\"");
				out.print(leavesid);
				out.print("\">");
				
				out.print("<option value=\"approved\">approved</option>");
				out.print("<option value=\"reject\">reject</option>");
				 
				
				out.print("</select>");
				out.print("</td>");
				
				out.write("</tr>");
				 out.write("<br>");
				 
				out.write("</table>");
				out.write("<input type=\"submit\">");
				out.write("<form>");
				
				
			}	
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	

}
