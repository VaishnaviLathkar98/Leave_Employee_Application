package com.myorg.leaveapp.controler;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myorg.leaveapp.bean.Leaves;
import com.myorg.leaveapp.bean.User;
import com.myorg.leaveapp.dao.LeavesDAO;


public class ReqLeavecontroler extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public ReqLeavecontroler() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String ltype= request.getParameter("ltype");
		String from_date=request.getParameter("from_date");
		String to_date=request.getParameter("to_date");
		String reason =request.getParameter("reason");
		
		Leaves leaves = new Leaves();
		
		leaves.setLtype(ltype);
		leaves.setFrom_date(from_date);
		leaves.setTo_date(to_date);
		leaves.setReason(reason);
		
		//Set Uid dynamically
		
		HttpSession sessiont= request.getSession();
		User user=(User) sessiont.getAttribute("user");
		leaves.setUid(user.getUid());
		
		leaves.setStatus("Applied");
		leaves.setDescription("==============");
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("DD/MM/YYYY");
		LocalDate localDate =LocalDate.now();
		leaves.setApplied_date(dtf.format(localDate));
		
		
		LeavesDAO leavesDAO = new LeavesDAO();
		try {
			leavesDAO.insert(leaves);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
