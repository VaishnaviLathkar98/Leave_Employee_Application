package com.myorg.leaveapp.controler;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.myorg.leaveapp.bean.User;
import com.myorg.leaveapp.dao.UserDAO;


public class MyController extends HttpServlet {
	public MyController()
	{

	}


	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		
		String username= request.getParameter("username");
		String passward=request.getParameter("passward");
		String role=request.getParameter("role");
		String status =request.getParameter("status");
		System.out.println("=============ok===================");

		User user = new User();
		user.setUsername(username);
		user.setPassward(passward);
		user.setRole(role);
		user.setStatus("Enable");
		UserDAO dao = new UserDAO();


		try {
			dao.insert(user);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("=============ok===================");

	}



}
