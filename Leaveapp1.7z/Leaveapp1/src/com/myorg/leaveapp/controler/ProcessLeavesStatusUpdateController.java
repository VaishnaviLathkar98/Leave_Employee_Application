package com.myorg.leaveapp.controler;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myorg.leaveapp.dao.LeavesDAO;


public class ProcessLeavesStatusUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
        
   
    public ProcessLeavesStatusUpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Enumeration< String> enumeration=request.getParameterNames();
		HashMap<String, String>	actionmap=new HashMap<String, String>();
		PrintWriter pr=response.getWriter();
		
		while(enumeration.hasMoreElements())
		{
			String temp = enumeration.nextElement();
			String value=request.getParameter(temp);
			pr.write(temp+" :"+value+"\n");
			actionmap.put(temp, value);
			
		}
		
		LeavesDAO leavesDAO = new LeavesDAO();
		try {
			leavesDAO.updateAllStatus(actionmap);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pr.write("leaves status of employee updated!!");
		
	}

	
}
