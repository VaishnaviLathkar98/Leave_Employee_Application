package com.myorg.leaveapp.controler;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myorg.leaveapp.bean.User;
import com.myorg.leaveapp.dao.UserDAO;

public class LoginControler extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public LoginControler() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String passward=request.getParameter("passward");
		
		
		UserDAO userDAO = new UserDAO();
		try {
		User user=	userDAO.chakeValidUser(username,passward);
			if(user==null)
			{
				response.sendRedirect("login.jsp");
			}
			else
			{
				HttpSession session= request.getSession();
				session.setAttribute("user",user);
				if(user.getRole().equalsIgnoreCase("manager"))
				{
				RequestDispatcher rd = request.getRequestDispatcher("navbar_mng.jsp");
				rd.forward(request, response);
				}
				else if(user.getRole().equalsIgnoreCase("employee"))
				{
					RequestDispatcher rd = request.getRequestDispatcher("nevbar_emp.jsp");
					rd.forward(request, response);
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
